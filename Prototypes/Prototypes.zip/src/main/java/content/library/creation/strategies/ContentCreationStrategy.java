package content.library.creation.strategies;

public interface ContentCreationStrategy {
    void generate();
}
