package content.library.validation;

import core.library.validation.Rule;
import core.library.validation.Validator;

public class ContentValidator implements Validator {
    @Override
    public boolean validate(Rule... rules) {
        return false;
    }
}
