package content.controllers;

import content.services.contracts.SearchService;
import core.library.context.Response;

public class SearchController {
    private SearchService service;

    public SearchController() {
    }

    public Response find(String name, String level, int channelId) {
        if ("channel".equals(level)) {
            return service.findInChannel(name, channelId);
        } else {
            return service.findInSystem(name);
        }
    }
}
