package content.entities.enums;

public enum ContentType {
    TEXT,
    MUSIC,
    VIDEO
}
