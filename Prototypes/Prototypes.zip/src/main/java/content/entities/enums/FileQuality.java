package content.entities.enums;

public enum FileQuality {
    _1080,
    _720,
    _480,
    _320,
    _128
}
