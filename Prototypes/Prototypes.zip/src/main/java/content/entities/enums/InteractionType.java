package content.entities.enums;

public enum InteractionType {
    LIKE,
    COMMENT
}
