package content.entities.enums;

public enum SubtitlePosition {
    UP,
    BOTTOM
}
