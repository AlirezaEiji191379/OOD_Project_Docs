package financial.entities.enums;

public enum TransactionType {
    SPEND,
    CHARGE,
    REFUND
}
