package financial.entities.enums;

public enum RefundStatus {
    COMPLETED,
    WAITING,
}
