package financial.entities.enums;

public enum TransactionStatus {
    COMPLETED,
    WAITING,
    FAILED
}
