package financial.jobs;

import financial.repositories.contracts.WalletRepository;
import financial.services.contracts.BankCoordinatorService;
import user.UserFacade;

public class BalanceRefundJob {
    private WalletRepository walletRepository;
    private BankCoordinatorService coordinatorService;
    private UserFacade userFacade;

    public BalanceRefundJob() {}

    public void refund() {
        walletRepository.findByUserId(11);
        coordinatorService.callBank(
                userFacade.getCurrentUser().getCardNumber(),
                10
        );
    }
}
