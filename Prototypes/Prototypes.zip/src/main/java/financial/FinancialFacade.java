package financial;

import financial.services.contracts.WalletService;

public class FinancialFacade {

    private WalletService walletService;

    public FinancialFacade() {
    }

    public boolean buy(int userId, int amount) {
        //check balance
        return false;
    }
}
