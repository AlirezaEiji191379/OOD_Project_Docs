package suggestion;

public class SuggestionFacade {
}
