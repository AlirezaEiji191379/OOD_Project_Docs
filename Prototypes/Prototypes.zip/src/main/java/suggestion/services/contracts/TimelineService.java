package suggestion.services.contracts;

import core.library.context.Response;

public interface TimelineService {
    Response load();
}
