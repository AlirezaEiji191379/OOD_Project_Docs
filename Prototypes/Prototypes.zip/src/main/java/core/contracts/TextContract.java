package core.contracts;

public class TextContract {
    private int contentId;
    private String value;

    public int getContentId() {
        return contentId;
    }

    public String getValue() {
        return value;
    }
}
