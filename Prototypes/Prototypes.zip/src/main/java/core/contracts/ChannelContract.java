package core.contracts;

public class ChannelContract {
    private int channelId;
    private String name;
    private String joinLink;
    private String picturePath;
    private String description;
}
