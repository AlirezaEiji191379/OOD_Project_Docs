package core.configuration;

import user.library.middleware.HttpContext;

public class DependencyInjection {
    public void install(HttpContext context) {

    }
}
