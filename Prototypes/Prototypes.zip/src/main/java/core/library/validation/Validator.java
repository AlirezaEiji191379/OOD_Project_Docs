package core.library.validation;

public interface Validator {
    boolean validate(Rule...rules);
}
