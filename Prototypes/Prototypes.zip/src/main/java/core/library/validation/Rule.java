package core.library.validation;

public interface Rule {
    boolean apply();
}
