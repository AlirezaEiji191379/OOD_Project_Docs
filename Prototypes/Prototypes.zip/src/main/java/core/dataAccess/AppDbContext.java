package core.dataAccess;

public class AppDbContext {
    public void commit() {
    }

    public void rollback() {

    }

    public void saveAsync() {

    }
}
