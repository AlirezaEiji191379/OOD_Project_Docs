package channel.entities.enums;

public enum SubscriptionPeriod {
    MONTH_3,
    MONTH_6,
    MONTH_12
}
