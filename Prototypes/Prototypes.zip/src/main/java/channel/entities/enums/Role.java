package channel.entities.enums;

public enum Role {
    ADMIN,
    OWNER,
    MEMBER
}
