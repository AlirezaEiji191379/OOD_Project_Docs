package user.context;

public class LoginRequest {
    
}
