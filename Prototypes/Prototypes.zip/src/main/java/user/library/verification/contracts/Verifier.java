package user.library.verification.contracts;

public interface Verifier {
    boolean verify();
}
