var searchData=
[
  ['example_0',['example',['../namespaceorg_1_1example.html',1,'org']]]
];
